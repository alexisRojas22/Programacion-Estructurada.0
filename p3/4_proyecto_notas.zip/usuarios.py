from coneccionBD import
import datetime
def registrar (nombre, apellido, email, contaseña)
    try:
       fecha=datetime. datetime, now()
       sql="insert into(nombre,apellido email. pasword) values (%s,%s)"
       val=(nombre,apellido,email,contraseña)
       cursor execute(sql,val)
       